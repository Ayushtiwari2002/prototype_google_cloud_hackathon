#!/bin/sh

set -eu pipefail

npm run serve